---
name: StellarX Submission
about: Submit OFW Insurance Premium Collector
title: "OFW Insurance Premium Collector"
labels: stellarx, submission
assignees: ""
---

## Project

OFW Insurance Premium Collector

## Idea Number

21

## Summary

OFW Insurance Premium Collector gives operators a shared settlement score trail, signed wallet actions, and a Soroban-backed release path that can be audited from dashboard to ledger.

## Stellar Usage

- Stellar testnet
- Soroban contract
- Freighter wallet
- Stellar SDK
- XLM/USDC SAC references
